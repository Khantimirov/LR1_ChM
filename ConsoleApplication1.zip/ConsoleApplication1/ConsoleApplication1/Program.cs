﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApplication1
{
    class Program
    {
        static void Main(string[] args)
        {
            double c = -0.1;
            int a = 0;
            int b = 1;
            int n = 0;
            double xn;
            double eps1 = 0.001;
            double x0 = Convert.ToDouble(Console.ReadLine());
            Console.WriteLine("Точность:"+eps1);
            if (x0 > a && x0 < b)
            {
                while (true)
                {
                    xn = x0 + c * (Math.Pow(Math.E, 2 * x0) + 3 * x0 - 4);
                    Console.WriteLine("n = {0}, x0 = {1}, xn = {2}",n, x0, xn);
                    n += 1;
                    if ((Math.Abs(xn - x0)) < eps1 && (Math.Abs(Math.Pow(Math.E, 2 * xn) + 3 * xn - 4)) < eps1)
                    {
                        break;
                    }
                    else
                    {
                        x0 = xn;
                    }
                }
            }
            else
            {
                Console.WriteLine("Ащипка");
            }
            Console.WriteLine("Ддапустим");
            Console.ReadKey();
        }
    }
}
